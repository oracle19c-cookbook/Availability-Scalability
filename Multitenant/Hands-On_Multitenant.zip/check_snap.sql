set linesize 200
set pagesize 1000
column pdb_name format a10
SELECT pdb_name, snapshot_mode, SNAPSHOT_INTERVAL FROM cdb_pdbs;