set linesize 200
set pagesize 1000
column snapshot_name format a26
column con_name format a8
column start_daate format a20
column full_snapshot_path format a60
SELECT --con_id,
       con_name,
       snapshot_name,
       --snapshot_scn,
       to_char(scn_to_timestamp(snapshot_scn), 'yyyy-mm-dd hh24:mi:ss') start_date,
       full_snapshot_path
FROM   cdb_pdb_snapshots
ORDER BY con_id, snapshot_scn;
