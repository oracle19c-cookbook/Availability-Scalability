set linesize 200
set pagesize 1000
column pdb_name format a10
column property_name format a20
column property_value format a20
SELECT pr.con_id,
       p.pdb_name,
       pr.property_name,
       pr.property_value
FROM   cdb_properties pr
       JOIN cdb_pdbs p ON pr.con_id = p.con_id
WHERE  pr.property_name = 'MAX_PDB_SNAPSHOTS'
ORDER BY pr.property_name;
